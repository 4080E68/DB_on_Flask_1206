from skimage import io,color
import numpy as np
from matplotlib import pyplot as plt#讀檔套件
from skimage import img_as_float
my_image = io.imread("D:/image2022/test.jpg",as_gray=False)


partial_img = my_image[50:100,50:200]
print(partial_img.shape)

print(my_image.min(),my_image.max())
plt.imshow(partial_img)

img_gray = color.rgb2gray(partial_img)
rows,cols = img_gray.shape
io.imshow(img_gray)


for i in range(rows):
    for j in range(cols):
        if (img_gray[i, j] <= 0.5):
            img_gray[i, j] = 0
        else:
            img_gray[i, j] = 1
            
io.imshow(img_gray)
io.show()

"""
random_image = np.random.random([500,500])
plt.imshow(random_image)
#print(random_image)
print(random_image.min(),random_image.max())"""